#!/bin/bash

## Softwares
htseq="HTSEQ"

## User variable
BAM=$1
GTF=$2
ncore=$3
outFile=$4

# Run HTseq-count
$htseq -f bam -s reverse -t exon --idattr gene_name \
 -m intersection-nonempty --nonunique all -n $ncore \
 $BAM $GTF > $outFile

