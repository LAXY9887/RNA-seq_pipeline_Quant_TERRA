#!/bin/bash

# Software
fastqdump="FASTQDUMP"

# User vars
SRA_file=$1
fastq_Path=$2

# Program
$fastqdump --split-files --gzip --outdir $fastq_Path $SRA_file

