#!/bin/bash

# Program
SRA_prefetch="PREFETCH"

# User vars
SRRID_file=$1
outDIR=$2

# Download
while read line
do
$SRA_prefetch ${line} -o ${outDIR}/${line}.sra &
done < $SRRID_file

